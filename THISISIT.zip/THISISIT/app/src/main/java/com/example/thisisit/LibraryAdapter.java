package com.example.thisisit;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class LibraryAdapter extends RecyclerView.Adapter<LibraryAdapter.ViewHolder> {

    private Context context;
    private List<SDCardItem> itemList;

    public LibraryAdapter(Context context, List<SDCardItem> itemList) {
        this.context = context;
        this.itemList = itemList;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView title;

        public ViewHolder(View view) {
            super(view);
            image = view.findViewById(R.id.image_sdcard);
            title = view.findViewById(R.id.text_filename);

        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_sdcard, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        SDCardItem item = itemList.get(position);
        holder.image.setImageResource(item.imageResId);
        holder.title.setText(item.title);

        holder.itemView.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("SD카드 정보")
                    .setMessage("획득일자: " + item.date + "\n기사: " + item.title)
                    .setPositiveButton("확인", null)
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }
}
