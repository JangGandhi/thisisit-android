package com.example.thisisit;

public class SDCardItem {
    public int imageResId;      // 카드에 표시할 이미지 (drawable)
    public String title;        // SD카드 제목 (예: 기사 제목)
    public String date;         // 획득 날짜
    public String articleLink;  // 기사 링크 (옵션)

    public SDCardItem(int imageResId, String title, String date, String articleLink) {
        this.imageResId = imageResId;
        this.title = title;
        this.date = date;
        this.articleLink = articleLink;
    }
}
