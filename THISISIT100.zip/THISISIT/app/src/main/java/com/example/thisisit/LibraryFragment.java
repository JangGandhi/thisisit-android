package com.example.thisisit;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;

// '라이브러리' 탭에 표시될 화면을 담당하는 Fragment 클래스
public class LibraryFragment extends Fragment {

    // 기본 생성자 - Fragment 생성 시 반드시 필요
    public LibraryFragment() {}

    // Fragment의 UI를 생성하는 메서드
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // fragment_library.xml 파일을 inflate(전개)하여 화면에 표시할 뷰를 생성
        return inflater.inflate(R.layout.fragment_library, container, false);
    }
}
