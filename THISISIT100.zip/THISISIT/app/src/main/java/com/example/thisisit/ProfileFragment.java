package com.example.thisisit;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

// ViewPager2에서 사용될 '프로필' 화면 프래그먼트
public class ProfileFragment extends Fragment {

    // 기본 생성자 - 반드시 필요
    public ProfileFragment() {}

    // Fragment의 UI를 설정하는 메서드
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // fragment_profile.xml 레이아웃을 전개하여 View 객체 생성
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // 전개된 뷰에서 텍스트뷰들을 ID로 찾아 연결
        TextView textGreeting = view.findViewById(R.id.text_greeting);
        TextView textArticles = view.findViewById(R.id.text_articles);
        TextView textSdCard = view.findViewById(R.id.text_sdcard);
        TextView textColoredSdCard = view.findViewById(R.id.text_colored_sdcard);

        // 예시 텍스트 설정 (실제 데이터는 추후에 전달받아 설정 가능)
        textGreeting.setText("반가워요! 박규선님");
        textArticles.setText("읽은 기사: 1개");
        textSdCard.setText("획득한 SD카드: 1개");
        textColoredSdCard.setText("획득한 색이 다른 SD카드: 0개");

        // 최종 구성된 뷰를 반환하여 화면에 표시
        return view;
    }
}
