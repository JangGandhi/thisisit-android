package com.example.thisisit;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Fragment9 extends Fragment {

    private TextView congratsText;
    private final int[] colors = {
            Color.parseColor("#FF4081"), // 핑크
            Color.parseColor("#FF9800"), // 오렌지
            Color.parseColor("#FFEB3B"), // 노랑
            Color.parseColor("#00BCD4"), // 시안
            Color.parseColor("#4CAF50"), // 초록
            Color.parseColor("#9C27B0")  // 보라
    };

    private int colorIndex = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable colorRunnable = new Runnable() {
        @Override
        public void run() {
            congratsText.setTextColor(colors[colorIndex]);
            colorIndex = (colorIndex + 1) % colors.length;
            handler.postDelayed(this, 300); // 300ms마다 색 변경
        }
    };

    public Fragment9() {}

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_9, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        congratsText = view.findViewById(R.id.congrats_text);
        handler.post(colorRunnable); // 시작
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        handler.removeCallbacks(colorRunnable); // 메모리 누수 방지
    }
}
