package com.example.thisisit;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.Switch;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Fragment5 extends Fragment {

    private Switch switch2;
    private Button btnUpChance, btnShinyChance, btnTryagainChance;
    private List<Button> bonusButtons;
    private String news = "BITCOIN";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_5, container, false);

        switch2 = view.findViewById(R.id.switch2);

        btnUpChance = view.findViewById(R.id.up_chance);
        btnShinyChance = view.findViewById(R.id.shiny_chance);
        btnTryagainChance = view.findViewById(R.id.tryagain_chance);

        // 버튼 스타일 적용
        btnTryagainChance.setBackgroundResource(R.drawable.button_red);
        btnShinyChance.setBackgroundResource(R.drawable.button_orange);
        btnUpChance.setBackgroundResource(R.drawable.button_green);

        bonusButtons = Arrays.asList(btnUpChance, btnShinyChance, btnTryagainChance);

        Bundle args = getArguments();
        switch2.setChecked(args == null || args.getBoolean("switchState", true));

        switch2.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!isChecked) {
                FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.container, new Fragment4());
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

        for (Button btn : bonusButtons) {
            btn.setVisibility(View.GONE);
            btn.setAlpha(0.4f);
            btn.setClickable(false);
        }

        Collections.shuffle(bonusButtons);
        Button selected = bonusButtons.get(0);
        selected.setVisibility(View.VISIBLE);
        showButtonWithTimer(selected, news);

        return view;
    }

    private void showButtonWithTimer(Button button, String news) {
        if (!cardAcquiredCheck(news)) {
            new CountDownTimer(10000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    button.setText(String.format("00:00:%02d", millisUntilFinished / 1000));
                }

                @Override
                public void onFinish() {
                    button.setAlpha(1.0f);
                    button.setClickable(true);

                    if (button == btnTryagainChance) {
                        button.setText("재시도 기회 한 번 더! SD카드 획득하기");
                        button.setOnClickListener(v -> {
                            saveBonus("max_retry", 2);
                            moveToFragment7();
                        });
                    } else if (button == btnShinyChance) {
                        button.setText("색이 다른 SD카드 획득하기");
                        button.setOnClickListener(v -> {
                            saveBonus("colored_sdcard", true);
                            moveToFragment7();
                        });
                    } else if (button == btnUpChance) {
                        button.setText("확률 UP! SD카드 획득하기");
                        button.setOnClickListener(v -> {
                            saveBonus("chance_bonus", 20);
                            moveToFragment7();
                        });
                    }

                    ScaleAnimation scale = new ScaleAnimation(1.0f, 1.1f, 1.0f, 1.1f,
                            ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
                            ScaleAnimation.RELATIVE_TO_SELF, 0.5f);
                    scale.setDuration(150);
                    scale.setRepeatCount(1);
                    scale.setRepeatMode(ScaleAnimation.REVERSE);
                    button.startAnimation(scale);
                }
            }.start();
        } else {
            disableButton(button, "이미 획득한 SD카드");
        }
    }

    private void disableButton(Button button, String text) {
        button.setClickable(false);
        button.setBackgroundResource(R.drawable.sd_disable_background);
        button.setText(text);
    }

    private void saveBonus(String key, Object value) {
        SharedPreferences prefs = requireContext().getSharedPreferences("quiz_data", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        if (value instanceof Integer) {
            editor.putInt(key, (Integer) value);
        } else if (value instanceof Boolean) {
            editor.putBoolean(key, (Boolean) value);
        }
        editor.apply();
    }

    private void moveToFragment7() {
        Fragment7 fragment7 = new Fragment7();
        Bundle bundle = new Bundle();
        bundle.putInt("stage", 2);
        fragment7.setArguments(bundle);

        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.container, fragment7);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    private boolean cardAcquiredCheck(String news) {
        File file = new File(requireContext().getFilesDir(), "Library.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("=");
                if (parts[0].equalsIgnoreCase(news + "_SDCARD_ACQUIRED_STAGE2") &&
                        Boolean.parseBoolean(parts[1].trim())) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
}