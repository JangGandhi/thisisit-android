package com.example.thisisit;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Fragment6 extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;
    private String target;
    private ArrayList<String> Question = new ArrayList<>();
    private ArrayList<Boolean> Answer = new ArrayList<>();
    private ArrayList<Integer> numbers = new ArrayList<>();

    private int currentIndex;
    private int correctCount;
    private double dropRate;
    private boolean resultUsed = false;
    private boolean hasRetried = false;

    private TextView textView, textView1, textView2, textView3;
    private Button btnRetry, btnResult;
    private LinearLayout linearLayout, resultButtons;

    public Fragment6() {}

    public static Fragment6 newInstance(String param1, String param2) {
        Fragment6 fragment = new Fragment6();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            target = getArguments().getString("difficulty");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_6, container, false);

        // 뷰 ID 연결
        textView = view.findViewById(R.id.textView);
        textView1 = view.findViewById(R.id.textView1);
        textView2 = view.findViewById(R.id.textView2); // O 버튼
        textView3 = view.findViewById(R.id.textView3); // X 버튼
        btnRetry = view.findViewById(R.id.btn_retry);
        btnResult = view.findViewById(R.id.btn_result);
        resultButtons = view.findViewById(R.id.result_buttons);
        linearLayout = view.findViewById(R.id.inner_layout); // ScrollView 내부 LinearLayout

        // 퀴즈 불러오기
        loadQuestions(target);

        if (!Question.isEmpty()) {
            startQuiz();
        } else {
            Toast.makeText(getContext(), "문제가 없습니다. Quiz.txt를 확인하세요.", Toast.LENGTH_LONG).show();
        }

        // O/X 버튼 클릭 리스너
        textView2.setOnClickListener(v -> handleAnswer(true));
        textView3.setOnClickListener(v -> handleAnswer(false));

        // SD카드 획득 버튼
        btnResult.setOnClickListener(v -> {
            if (resultUsed) {
                Toast.makeText(getContext(), "이미 결과를 확인했습니다.", Toast.LENGTH_SHORT).show();
                return;
            }

            resultUsed = true;

            int chance = (int)(dropRate * 100);
            int random = (int)(Math.random() * 100) + 1;

            if (random <= chance) {
                updateTotal();
                updateLibrary();
                Toast.makeText(getContext(), "SD 카드를 획득하셨습니다!", Toast.LENGTH_LONG).show();

                Fragment8 fragment8 = new Fragment8();
                FragmentTransaction transaction = requireActivity()
                        .getSupportFragmentManager()
                        .beginTransaction();
                transaction.replace(R.id.container, fragment8);
                transaction.addToBackStack(null);
                transaction.commit();
            } else {
                Toast.makeText(getContext(), "SD 카드 획득에 실패했습니다.", Toast.LENGTH_LONG).show();
            }
        });

        // 재시도 버튼 클릭 리스너
        btnRetry.setOnClickListener(v -> {
            if (hasRetried) {
                Toast.makeText(getContext(), "재시도는 1번만 가능합니다.", Toast.LENGTH_SHORT).show();
                return;
            }

            hasRetried = true;
            currentIndex = 0;
            correctCount = 0;
            Collections.shuffle(numbers);
            resultButtons.setVisibility(View.GONE);

            Toast.makeText(getContext(), "새로운 문제로 재시작합니다.", Toast.LENGTH_SHORT).show();
            updateQuiz();
        });

        return view;
    }


    private void loadQuestions(String target) {
        BufferedReader reader = null;
        String line;
        linearLayout.setBackgroundColor(target.equalsIgnoreCase("easy") ? Color.parseColor("#003850") : Color.parseColor("#1C3800"));

        try {
            InputStream is = requireContext().getAssets().open("quiz.txt");
            reader = new BufferedReader(new InputStreamReader(is));

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("=");
                if (parts.length == 3) {
                    String question = parts[0].trim();
                    boolean answer = Boolean.parseBoolean(parts[1].trim());
                    String difficulty = parts[2].trim();
                    if (difficulty.equalsIgnoreCase(target)) {
                        Question.add(question);
                        Answer.add(answer);
                    }
                }
            }

            Log.d("QuizDebug", "문제 로딩 완료: " + Question.size() + "개");

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try { if (reader != null) reader.close(); } catch (IOException e) { e.printStackTrace(); }
        }
    }

    private void startQuiz() {
        numbers.clear();
        correctCount = 0;

        if (Question.size() < 5) {
            Toast.makeText(getContext(), "문제가 5개 이상 필요합니다.", Toast.LENGTH_LONG).show();
            return;
        }

        for (int i = 0; i < Math.min(Question.size(), 10); i++) {
            numbers.add(i);
        }
        Collections.shuffle(numbers);
        currentIndex = 0;
        dropRate = 0.2;
        updateQuiz();
    }

    private void updateQuiz() {
        if (currentIndex < 5 && currentIndex < numbers.size()) {
            textView.setText((currentIndex + 1) + "/5");
            textView1.setText(Question.get(numbers.get(currentIndex)));
            textView2.setEnabled(true);
            textView3.setEnabled(true);
        } else {
            dropRate = getChanceByCorrectCount(correctCount); //
            btnResult.setText("SD카드 획득하기 (" + (int)(dropRate * 100) + "%)");
            resultButtons.setVisibility(View.VISIBLE);
        }
    }
    // 확률 값 함수
    private double getChanceByCorrectCount(int correct) {
        switch (correct) {
            case 0: return 0.10;
            case 1: return 0.20;
            case 2: return 0.40;
            case 3: return 0.50;
            case 4: return 0.60;
            case 5: return 0.80;
            default: return 0.0;
        }
    }


    private void handleAnswer(boolean userAnswer) {
        if (currentIndex >= numbers.size()) return;

        textView2.setEnabled(false);
        textView3.setEnabled(false);

        if (Answer.get(numbers.get(currentIndex)) == userAnswer) {
            correctCount++;
            Toast.makeText(getContext(), "정답입니다!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getContext(), "오답입니다!", Toast.LENGTH_SHORT).show();
        }

        updateCorrect();
        updateTried();
        currentIndex++;
        updateQuiz();
    }

    private void updateProfile(String key) {
        File file = new File(requireContext().getFilesDir(), "Profile.txt");
        String line;
        List<String> lines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("=");
                if (parts[0].equalsIgnoreCase(key)) {
                    int updated = Integer.parseInt(parts[1]) + 1;
                    lines.add(parts[0] + "=" + updated);
                } else {
                    lines.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (String l : lines) {
                writer.write(l);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void updateTotal() { updateProfile("TOTAL_SDCARD_COUNT"); }
    private void updateTried() { updateProfile("TRIED_QUIZ_COUNT"); }
    private void updateCorrect() { updateProfile("CORRECT_QUIZ_COUNT"); }

    private void updateLibrary() {
        File file = new File(requireContext().getFilesDir(), "Library.txt");
        String line;
        List<String> lines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("=");
                if (parts[0].equalsIgnoreCase("BITCOIN_SDCARD_ACQUIRED") && !Boolean.parseBoolean(parts[1].trim())) {
                    lines.add(parts[0] + "=true");
                } else {
                    lines.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (String l : lines) {
                writer.write(l);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
