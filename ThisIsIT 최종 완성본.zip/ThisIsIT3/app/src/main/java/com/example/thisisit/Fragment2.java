package com.example.thisisit;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

import java.io.*;

public class Fragment2 extends Fragment {

    private TextView textView;

    public Fragment2() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_2, container, false);
        textView = view.findViewById(R.id.textView);

        File file = new File(requireContext().getFilesDir(), "Library.txt");

        if (!file.exists()) {
            textView.setText("도감 정보 파일(Library.txt)이 존재하지 않습니다.");
            return view;
        }

        StringBuilder rawData = new StringBuilder(); // 전체 줄 저장
        int normalCount = 0;
        int specialCount = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;

            while ((line = reader.readLine()) != null) {
                rawData.append(line).append("\n");

                if (line.contains("=")) {
                    String[] parts = line.split("=");
                    String key = parts[0].trim();
                    String value = parts[1].trim();

                    if (value.equalsIgnoreCase("true")) {
                        if (key.endsWith("_SDCARD_ACQUIRED_STAGE2")) specialCount++;
                        else if (key.endsWith("_SDCARD_ACQUIRED")) normalCount++;
                    }
                }
            }
        } catch (IOException e) {
            textView.setText("Library.txt 읽기 중 오류 발생");
            e.printStackTrace();
            return view;
        }

        StringBuilder finalOutput = new StringBuilder();
        finalOutput.append("📁 일반 SD카드: ").append(normalCount).append("개\n");
        finalOutput.append("🌈 색이 다른 SD카드: ").append(specialCount).append("개\n\n");
        finalOutput.append(rawData);

        textView.setText(finalOutput.toString().trim());
        return view;
    }
}
