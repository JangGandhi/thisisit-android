package com.example.thisisit;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.io.*;
import java.util.*;

public class Fragment7 extends Fragment {

    private ArrayList<String> Question = new ArrayList<>();
    private ArrayList<Boolean> Answer = new ArrayList<>();
    private ArrayList<Integer> numbers = new ArrayList<>();

    private int currentIndex;
    private int correctCount;
    private double dropRate;

    private boolean hasRetried = false;
    private boolean resultUsed = false;
    private int maxRetry = 1;

    private final String SD_CARD_KEY = "BITCOIN_SDCARD_ACQUIRED_STAGE2";

    private TextView textProgress, textQuestion, btnO, btnX;
    private Button btnRetry, btnResult;
    private LinearLayout layout, resultButtons;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_7, container, false);

        // View 연결
        textProgress = view.findViewById(R.id.textView);
        textQuestion = view.findViewById(R.id.textView_question);
        btnO = view.findViewById(R.id.btn_o);
        btnX = view.findViewById(R.id.btn_x);
        btnRetry = view.findViewById(R.id.btn_retry);
        btnResult = view.findViewById(R.id.btn_result);
        resultButtons = view.findViewById(R.id.result_buttons);
        layout = view.findViewById(R.id.layout);
        layout.setBackgroundColor(Color.parseColor("#1C3800"));

        applyBonus();

        if (isAlreadyAcquired()) {
            Toast.makeText(getContext(), "이미 획득한 SD카드입니다.", Toast.LENGTH_LONG).show();
            disableAll();
            return view;
        }

        if (isAlreadyChecked()) {
            Toast.makeText(getContext(), "이미 결과를 확인했습니다.", Toast.LENGTH_LONG).show();
            disableAll();
            return view;
        }

        loadHardQuestions();

        if (!Question.isEmpty()) {
            startQuiz();
        } else {
            Toast.makeText(getContext(), "문제가 없습니다. quiz.txt 확인 필요.", Toast.LENGTH_LONG).show();
        }

        btnO.setOnClickListener(v -> handleAnswer(true));
        btnX.setOnClickListener(v -> handleAnswer(false));

        btnRetry.setOnClickListener(v -> {
            if (resultUsed) {
                Toast.makeText(getContext(), "이미 결과를 확인했습니다.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!hasRetried && maxRetry > 0) {
                hasRetried = true;
                maxRetry--;
                resetQuiz();
                Toast.makeText(getContext(), "재도전 시작!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "재시도는 최대 " + (maxRetry + 1) + "회까지 가능합니다.", Toast.LENGTH_SHORT).show();
            }
        });

        btnResult.setOnClickListener(v -> {
            if (resultUsed || isAlreadyChecked()) {
                Toast.makeText(getContext(), "이미 결과를 확인했습니다.", Toast.LENGTH_SHORT).show();
                return;
            }

            resultUsed = true;
            saveChecked();

            int chance = (int)(dropRate * 100);
            int random = new Random().nextInt(100) + 1;

            if (random <= chance) {
                markAcquired();
                updateProfile("TOTAL_SDCARD_COUNT");
                Toast.makeText(getContext(), "획득 성공!", Toast.LENGTH_SHORT).show();

                boolean colored = requireContext()
                        .getSharedPreferences("quiz_data", Context.MODE_PRIVATE)
                        .getBoolean("colored_sdcard", false);

                Fragment next = colored ? new Fragment9() : new Fragment8();
                FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.container, next);
                transaction.addToBackStack(null);
                transaction.commit();

            } else {
                Toast.makeText(getContext(), "획득 실패!", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

    private void applyBonus() {
        SharedPreferences prefs = requireContext().getSharedPreferences("quiz_data", Context.MODE_PRIVATE);
        dropRate = 0.2 + prefs.getInt("chance_bonus", 0) / 100.0;
        maxRetry = prefs.getInt("max_retry", 1); // 기본 1, 보너스 시 2
    }

    private void disableAll() {
        btnO.setEnabled(false);
        btnX.setEnabled(false);
        btnResult.setEnabled(false);
        btnRetry.setEnabled(false);
        resultButtons.setVisibility(View.GONE);
    }

    private void loadHardQuestions() {
        try (InputStream is = requireContext().getAssets().open("quiz.txt");
             BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("=");
                if (parts.length == 3 && parts[2].trim().equalsIgnoreCase("hard")) {
                    Question.add(parts[0].trim());
                    Answer.add(Boolean.parseBoolean(parts[1].trim()));
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void startQuiz() {
        numbers.clear();
        correctCount = 0;

        if (Question.size() < 5) {
            Toast.makeText(getContext(), "문제가 5개 이상 필요합니다.", Toast.LENGTH_LONG).show();
            return;
        }

        for (int i = 0; i < Math.min(Question.size(), 10); i++) {
            numbers.add(i);
        }

        Collections.shuffle(numbers);
        currentIndex = 0;
        updateQuiz();
    }

    private void resetQuiz() {
        Question.clear();
        Answer.clear();
        numbers.clear();
        correctCount = 0;
        resultUsed = false;
        resultButtons.setVisibility(View.GONE);
        loadHardQuestions();
        startQuiz();
    }

    private void updateQuiz() {
        if (currentIndex < 5 && currentIndex < numbers.size()) {
            textProgress.setText((currentIndex + 1) + "/5");
            textQuestion.setText(Question.get(numbers.get(currentIndex)));
            btnO.setEnabled(true);
            btnX.setEnabled(true);
        } else {
            dropRate = getChanceByCorrectCount(correctCount);  //
            btnResult.setText("SD카드 획득하기 (" + (int)(dropRate * 100) + "%)");
            resultButtons.setVisibility(View.VISIBLE);
        }
    }
    private double getChanceByCorrectCount(int correct) {
        switch (correct) {
            case 0: return 0.10;
            case 1: return 0.20;
            case 2: return 0.40;
            case 3: return 0.50;
            case 4: return 0.60;
            case 5: return 0.80;
            default: return 0.0;
        }
    }


    private void handleAnswer(boolean userAnswer) {
        if (currentIndex >= numbers.size()) return;

        btnO.setEnabled(false);
        btnX.setEnabled(false);

        if (Answer.get(numbers.get(currentIndex)) == userAnswer) {
            correctCount++;
            updateProfile("CORRECT_QUIZ_COUNT");
            Toast.makeText(getContext(), "정답!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getContext(), "오답!", Toast.LENGTH_SHORT).show();
        }

        updateProfile("TRIED_QUIZ_COUNT");
        currentIndex++;
        updateQuiz();
    }

    private void updateProfile(String key) {
        File file = new File(requireContext().getFilesDir(), "Profile.txt");
        List<String> lines = new ArrayList<>();
        String line;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("=");
                if (parts[0].equalsIgnoreCase(key)) {
                    int updated = Integer.parseInt(parts[1]) + 1;
                    lines.add(parts[0] + "=" + updated);
                } else {
                    lines.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (String l : lines) {
                writer.write(l);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void markAcquired() {
        File file = new File(requireContext().getFilesDir(), "Library.txt");
        List<String> lines = new ArrayList<>();
        boolean found = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(SD_CARD_KEY)) {
                    lines.add(SD_CARD_KEY + "=true");
                    found = true;
                } else {
                    lines.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (!found) lines.add(SD_CARD_KEY + "=true");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (String l : lines) {
                writer.write(l);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveChecked() {
        SharedPreferences prefs = requireContext().getSharedPreferences("quiz_data", Context.MODE_PRIVATE);
        prefs.edit().putBoolean("sdcard_checked", true).apply();
    }

    private boolean isAlreadyChecked() {
        SharedPreferences prefs = requireContext().getSharedPreferences("quiz_data", Context.MODE_PRIVATE);
        return prefs.getBoolean("sdcard_checked", false);
    }

    private boolean isAlreadyAcquired() {
        File file = new File(requireContext().getFilesDir(), "Library.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("=");
                if (parts[0].equalsIgnoreCase(SD_CARD_KEY)) {
                    return Boolean.parseBoolean(parts[1].trim());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
}
